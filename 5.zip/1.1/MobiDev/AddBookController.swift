//
//  AddBookController.swift
//  MobiDev
//
//  Created by Cockerman on 05.05.2021.
//

import UIKit


class AddBookController: UIViewController {
    @IBOutlet weak var titleField: UITextField!
    @IBOutlet weak var subtitleField: UITextField!
    @IBOutlet weak var priceField: UITextField!       
    @IBOutlet weak var AddBookConfirmButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        titleField.becomeFirstResponder()
        titleField.keyboardAppearance = .light
        subtitleField.keyboardAppearance = .light
        priceField.keyboardAppearance = .light
        priceField.keyboardType = .numbersAndPunctuation //numberPad keyboard не має ','
        
    }
        
    
    func hideKeyboardWhenTappedAround() {
            let tap = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard))
            tap.cancelsTouchesInView = false
            view.addGestureRecognizer(tap)
        }
        
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddBookConfirmSegue"{
            let receivingVC = segue.destination as! ListViewController
            if let text = titleField.text {
                receivingVC.addBookTitle = text
            }else{ receivingVC.addBookTitle = "No title" }
            
            if let text = subtitleField.text {
                receivingVC.addBookSubtitle = text
            }else{ receivingVC.addBookSubtitle = "No subtitle" }
            
            if let text = priceField.text {
                if Double(text) != nil {
                receivingVC.addBookPrice = text + "$"
                }else{ receivingVC.addBookPrice = "No price"}
            }else{ receivingVC.addBookPrice = "No price" }
            
            receivingVC.justAdded = true
            navigationController?.popViewController(animated: false)
        }
        
    }
    
}
