//
//  ImageCollectionViewController.swift
//  MobiDev
//
//  Created by Cockerman on 08.05.2021.
//

import UIKit

class CollectionViewCell1: UICollectionViewCell{
    @IBOutlet weak var ImageView1: UIImageView!    
}

class CollectionViewCell3: UICollectionViewCell{
    @IBOutlet weak var ImageView3: UIImageView!
}

var imageNum = 0
var bigOneTime = false
var smallWidth = CGFloat(0.0)
var bigWidth = CGFloat(0.0)


class ImageCollectionViewController: UICollectionViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var images = [UIImage]()
    
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if bigOneTime{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell1", for: indexPath) as! CollectionViewCell1
            //cell.translatesAutoresizingMaskIntoConstraints = false
            //cell.topAnchor.constraint(equalTo: collectionView.topAnchor).isActive = true
            cell.ImageView1.image = images[indexPath.item]

            /*cell.ImageView3.translatesAutoresizingMaskIntoConstraints = false
            cell.ImageView3.centerXAnchor.constraint(equalTo: cell.centerXAnchor).isActive = true
            cell.ImageView3.centerYAnchor.constraint(equalTo: cell.centerYAnchor).isActive = true
            cell.ImageView3.heightAnchor.constraint(equalToConstant: bigWidth).isActive = true
            cell.ImageView3.widthAnchor.constraint(equalToConstant: bigWidth).isActive = true*/
        
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell1", for: indexPath) as! CollectionViewCell1
            cell.ImageView1.image = images[indexPath.item]

            //cell.ImageView1.translatesAutoresizingMaskIntoConstraints = false
            /*cell.ImageView1.centerXAnchor.constraint(equalTo: cell.centerXAnchor).isActive = true
            cell.ImageView1.centerYAnchor.constraint(equalTo: cell.centerYAnchor).isActive = true
            cell.ImageView1.heightAnchor.constraint(equalToConstant: smallWidth).isActive = true
            cell.ImageView1.widthAnchor.constraint(equalToConstant: smallWidth).isActive = true*/
        
            return cell
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
               
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add photo", style: UIBarButtonItem.Style.plain, target: self, action: #selector(importPicture))
        
        let layout = collectionViewLayout as! ImageLayout
        layout.delegate = self
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        collectionView.reloadData()
    }
    
    @objc func importPicture(){
        let picker = UIImagePickerController()
        picker.allowsEditing = true
        picker.delegate = self
        present(picker, animated: true)
    }
    
    /* For Flow
     func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if ((indexPath.item-1) % 7 == 0){
            bigOneTime = true
            bigWidth = (collectionView.frame.width-20)*3/5
            return CGSize(width: bigWidth, height: bigWidth)
        }else{
            bigOneTime = false
            smallWidth = (collectionView.frame.width-20)/5
            return CGSize(width: smallWidth, height: smallWidth)
        }
    }*/
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage else {return}
        dismiss(animated: true)
        
        
        images.append(image)
        collectionView.reloadData()
    }
        
}

extension ImageCollectionViewController: ImageLayoutDelegate{
    func collectionView(collectionView: UICollectionView, widthForItemAtIndexPath indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
