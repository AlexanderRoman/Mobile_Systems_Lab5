//
//  ImageLayout.swift
//  MobiDev
//
//  Created by Cockerman on 09.05.2021.
//

import UIKit

protocol ImageLayoutDelegate{
    func collectionView(collectionView: UICollectionView, widthForItemAtIndexPath indexPath: IndexPath) -> CGFloat
}


class ImageLayout: UICollectionViewLayout {
    var delegate: ImageLayoutDelegate!
    var numberOfColumns = 3
    
    var columnWidth1:CGFloat{ get {(collectionView!.bounds.width-20)/5}}
    var columnWidth3:CGFloat{ get {(collectionView!.bounds.width-20)*3/5}}
    var itsBigOne = false
    //var skipps = 0
    private var cache = [UICollectionViewLayoutAttributes]()
    //private var height: CGFloat = 0
    var width: CGFloat{
        get{
            return collectionView!.frame.width
        }
    }
    var height = CGFloat(0.0)
    
    override var collectionViewContentSize: CGSize{
        /*if itsBigOne{
            itsBigOne = false
            return CGSize(width: columnWidth3, height: columnWidth3)
        }else{
            return CGSize(width: columnWidth1, height: columnWidth1)
        }*/
        return CGSize(width: width, height: height)
    }
    
    override func prepare() {
        var skipps = 0
        var columnWidth1 = (collectionView!.bounds.width-4)/5
        var columnWidth3 = (collectionView!.bounds.width-4)*3/5
        var xOffsets = [0.0, columnWidth1+2, columnWidth3+columnWidth1+4]
        var yOffsets = [CGFloat(0.0), CGFloat(0.0), CGFloat(0.0)]
        
        var column = 0
        var item = 0
        for item in 0..<collectionView!.numberOfItems(inSection: 0){
            if skipps>0 && column == 1{
                skipps-=1
                /*if skipps == 0{
                    yOffsets[1] += columnWidth3
                }*/
                column += 1
                
            }
            let myIndexPath = IndexPath(item: item, section: 0)
                
            var frame: CGRect
            if (item-1)%7 == 0{
                frame = CGRect(x: xOffsets[column], y: yOffsets[column], width: columnWidth3, height: columnWidth3+4)
                itsBigOne = true
                skipps = 2
            }else{frame = CGRect(x: xOffsets[column], y: yOffsets[column], width: columnWidth1, height: columnWidth1)}
            let attributes = UICollectionViewLayoutAttributes(forCellWith: myIndexPath)
            attributes.frame = frame
            cache.append(attributes)
            if (item-1)%7 != 0{
                yOffsets[column] = yOffsets[column] + columnWidth1 + 2
            }else{yOffsets[column] = yOffsets[column] + columnWidth3 + 6}
                height = yOffsets.max()!
            if column >= (numberOfColumns - 1){
                    column = 0
                }else{
                    column += 1
                }
            
        }
    }
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        var layoutAttributes = [UICollectionViewLayoutAttributes]()
        for attributes in cache{
            //if attributes.frame.intersects(rect){
                layoutAttributes.append(attributes)
            //}
        }        
        return layoutAttributes
    }
}
